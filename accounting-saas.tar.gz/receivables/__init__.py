default_app_config = "receivables.apps.ReceivablesConfig"
